class ServiceCandidata extends Relatorio{
    
}